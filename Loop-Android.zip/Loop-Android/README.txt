LOOP ANDROID PROJECT

This project wraps the latest Loop HTML app in an Android WebView.

BUILD AN APK
1. Install Android Studio on a Windows, Mac, or Linux computer.
2. Extract the Loop-Android.zip file.
3. In Android Studio choose Open, then select the extracted Loop-Android folder.
4. Allow Android Studio to sync/download the Android Gradle plugin and Android SDK components it requests.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build finishes, click the APK location link shown by Android Studio. The APK is normally in app/build/outputs/apk/debug/app-debug.apk.
7. Move that APK to your Android phone and install it. Android may ask you to allow installs from that file manager.

NOTES
- App name: Loop
- Package ID: com.loopapp.social
- Minimum Android version: Android 6.0 (API 23)
- The app needs internet access for Supabase and remote content.
- This is a debug APK build setup. A Play Store release needs a signed release build.
- The HTML is bundled locally; Supabase remains the online backend.
